import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import Layout from '../../Layout/Layout';
// import { cancelCourseBundle } from '../../Redux/razorpaySlice'; // <-- REMOVED
import { getUserData } from '../../Redux/authSlice';
import { BsPersonCircle } from 'react-icons/bs';

const Profile = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // getting user data from slice
  const { data } = useSelector((state) => state.auth);

  // function to handle subscription cancel
  // const handleSubscriptionCancel = async () => {   // <-- REMOVED
  //   toast('Initiating cancellation...');
  //   await dispatch(cancelCourseBundle());
  //   await dispatch(getUserData());
  //   toast.success('Cancellation complete');
  //   navigate('/');
  // };

  useEffect(() => {
    // getting user details
    dispatch(getUserData());
  }, [dispatch]);

  return (
    <Layout>
      <div className="min-h-[90vh] flex items-center justify-center">
        <div className="my-10 flex flex-col gap-4 rounded-lg p-4 text-white w-96 shadow-[0_0_10px_black]">
          {data?.avatar?.secure_url ? (
            <img
              src={data?.avatar?.secure_url}
              alt="user profile"
              className="w-40 h-40 m-auto rounded-full border border-black"
            />
          ) : (
            <BsPersonCircle className="w-40 h-40 m-auto rounded-full border border-black" />
          )}

          <h3 className="text-xl font-semibold text-center capitalize">
            {data.fullName}
          </h3>

          <div className="grid grid-cols-2">
            <p>Email : </p>
            <p className="overflow-hidden truncate">{data?.email}</p>
            <p>Role : </p>
            <p>{data?.role}</p>

            {/* We are no longer using subscriptions */}
            {/* <p>Subscription : </p> */}
            {/* <p> */}
            {/* {data?.subscription?.status === 'active' ? 'Active' : 'Inactive'} */}
            {/* </p> */}
          </div>

          <div className="flex items-center justify-between gap-2">
            <Link
              to={'/changepassword'}
              className="w-1/2 bg-yellow-600 hover:bg-yellow-500 transition-all ease-in-out duration-300 rounded-sm font-semibold py-2 cursor-pointer text-center"
            >
              Change Password
            </Link>
            <Link
              to={'/user/editprofile'}
              className="w-1/2 bg-yellow-600 hover:bg-yellow-500 transition-all ease-in-out duration-300 rounded-sm font-semibold py-2 cursor-pointer text-center"
            >
              Edit Profile
            </Link>
          </div>

          {/* We are no longer using subscriptions, so remove button */}
          {/* {data?.subscription?.status === 'active' && (
            <button
              onClick={handleSubscriptionCancel}
              className="w-full bg-red-600 hover:bg-red-500 transition-all ease-in-out duration-300 rounded-sm font-semibold py-2 cursor-pointer text-center"
            >
              Cancel Subscription
            </button>
          )} */}
        </div>
      </div>
    </Layout>
  );
};

export default Profile;
